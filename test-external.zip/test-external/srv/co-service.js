const cds = require('@sap/cds')

module.export = cds.service.impl(async function () {
    const { Products } = this.entities;

    const service = await cds.connect.to('NorthWind');
	this.on('READ', Products, request => {
		return service.tx(request).run(request.query);
	});
})